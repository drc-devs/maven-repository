package com.drc.reference

import pt.tumba.spell.SpellChecker

class SpellCheckerWrapper {
  private SpellChecker spellChecker
  
  SpellCheckerWrapper(){}
  
  SpellCheckerWrapper(def dictionary){
    def fullPath = Thread.currentThread().getContextClassLoader().getResource(dictionary).getFile()
    spellChecker = new SpellChecker()
    spellChecker.initialize(fullPath);
  }
  
  def spellCheck(word) {
    spellChecker.findMostSimilarList(word, false)
  }
}
