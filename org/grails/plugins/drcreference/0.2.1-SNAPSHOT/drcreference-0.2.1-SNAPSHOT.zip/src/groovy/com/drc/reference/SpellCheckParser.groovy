package com.drc.reference

import grails.converters.JSON;
import org.codehaus.groovy.grails.web.json.JSONArray

class SpellCheckParser {

  def cleanWord = { word ->
    def returnValue = []
    def spanMatch = /\w+(?=<\/span>)/
    word = word.replaceAll(/&\w+;|\*/, '')
    
    if (word.contains('</span>')) {
      def matcher = (word =~ spanMatch)
      matcher.each {
        if (shouldAdd(it))
          returnValue.add(it)
      }
    } else {
      if (shouldAdd(word))
        returnValue.add(word)
    }
    
    returnValue
  }
  
  def shouldAdd(word) {
    !(word ==~ /.*[^\w].*/)
  }
  
  def parseUro = { uro ->
    def returnValue = []
    if (uro) {
      if (uro instanceof JSONArray) {
        uro.each { returnValue += parseUro(it) }
      } else {
        returnValue += cleanWord(uro.ure)
        returnValue += parseVr(uro.vr)
        returnValue += parseIn(uro.in)
      }
    }
    returnValue
  }
  
  def parseIn = {
    def returnValue = []
    if (it) {
      if (it instanceof JSONArray) {
        it.each { returnValue += parseIn(it) }
      } else {
        if (it instanceof String)
          returnValue += cleanWord(it)
        else
          returnValue += cleanWord(it.$text)
      }
    }
    returnValue
  }
  
  def parseVr = { vr ->
    def returnValue = []
    
    if (vr?.va) {
      if (vr.va instanceof JSONArray)
        vr.va.each { returnValue += cleanWord(it) }
      else
        returnValue += cleanWord(vr.va)
    }
    
    returnValue
  }
  
  def parseEntry(entryJson) {
    def entry = JSON.parse(entryJson)
    def words = []
    
    entry.each {
      if (!(it.originalWord ==~ /.*[\s-].*/)) {
        words += it.originalWord
        words += parseVr(it.vr)
        words += parseIn(it.in)
        words += parseUro(it.uro)
      }
    }
    
    words
  }
}
