package com.drc.reference

import org.apache.commons.io.FileUtils

class SpellCheckParser {
  static String DATA_PATH = 'spellcheck/'
  static String OUTPUT_PATH = 'target/tomcat-db/spelling'

  def grailsApplication
  def dataPath = DATA_PATH
  def outputPath = OUTPUT_PATH
  TreeSet present = new TreeSet()

  SpellCheckParser(){

    def referenceConfig = grailsApplication?.config?.drcreference

    if (referenceConfig) {
      dataPath = referenceConfig.spellingDataDir ?: DATA_PATH
      outputPath = referenceConfig.dictionaryPath ?: OUTPUT_PATH
    }

    def outfile = new File(outputPath)
    FileUtils.deleteDirectory(outfile)
    outfile.mkdirs()
    dataPath = Thread.currentThread().getContextClassLoader().getResource(dataPath).getFile()
  }

  def createSpellcheckDictionary(){
    def wordcount = 0
    def inFile = getInFile()
    def outStream = new BufferedOutputStream(new FileOutputStream("${OUTPUT_PATH}/dictionary.txt"))

    try {
      inFile.eachLine {
        def words = it.replaceAll(/\[.*]/, "").split("[\\s+|,]")
        wordcount += submitToDictionary(words, outStream)
      }
      wordcount
    }
    finally {
      outStream?.flush()
      outStream?.close()
    }
  }

  def submitToDictionary(words, outStream){
    def wordcount = 0

    words.each { word ->
      word = word.replaceAll(/\[.*]/, "").toLowerCase()
      if (shouldAdd(word, present)) {
        present.add(word)
        outStream << "$word : 1${System.getProperty('line.separator')}"
        ++wordcount
      }
    }
    wordcount
  }

  def shouldAdd(word, present){
    word.size() > 0 && !present.contains(word) && !(word ==~ ".*[\\s-:;.,&()].*")
  }

  def getInFile() {
    new File("${dataPath}mwData.csv")
  }
}
