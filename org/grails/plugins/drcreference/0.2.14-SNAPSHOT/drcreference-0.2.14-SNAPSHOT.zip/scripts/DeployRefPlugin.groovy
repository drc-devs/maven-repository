includeTargets << new File(releasePluginDir, "scripts/_GrailsMaven.groovy")

target(main:"Installs a Grails plugin as a Maven artefact") {
    depends(parseArguments, mavenDeploy)
    println "Maven deploy complete."
}
setDefaultTarget(main)