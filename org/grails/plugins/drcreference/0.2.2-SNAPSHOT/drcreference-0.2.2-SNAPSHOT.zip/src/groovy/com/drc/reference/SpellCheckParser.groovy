package com.drc.reference


class SpellCheckParser {
  static String DATA_PATH = 'spellcheck/'
  static String OUTPUT_PATH = 'target/tomcat-db/spelling/dictionary.txt'
  
  def grailsApplication
  def dataPath = DATA_PATH
  def outstream
  TreeSet sdSet = new TreeSet()
  TreeSet present = new TreeSet()
  
  SpellCheckParser(){
    def referenceConfig = grailsApplication?.config?.drcreference 
    
    if (referenceConfig) {
      dataPath = referenceConfig.spellingDataDir ?
                 referenceConfig.spellingDataDir :
                 DATA_PATH
                 
      def outputPath = referenceConfig.dictionaryPath ?
                   referenceConfig.dictionaryPath :
                   OUTPUT_PATH
      outstream = new FileOutputStream(outputPath)           
    } else {
      outstream = new FileOutputStream(OUTPUT_PATH)
    }
    dataPath = Thread.currentThread().getContextClassLoader().getResource(dataPath).getFile()
  }
  
  SpellCheckParser(outstream) {
    this()
    if (outstream)
      this.outstream = outstream
  }
  
  def createSpellcheckDictionary(){
    def wordcount = 0
    def inStreams = getInputStreams()
    
    setupDictionary(inStreams.sd)
    
    inStreams.mwData.eachLine {
      def words = it.replaceAll(/\[.*]/, "").split("[\\s+|,]")
    
      wordcount += submitToDictionary(words)
    }
    
    wordcount
  }
  
  def setupDictionary(sd){
    sd.eachLine{
      sdSet.add(it.toLowerCase())
    }
  }
  
  def submitToDictionary(words){
    def key = words[0].toLowerCase()
    def wordcount = 0
    
    if (sdSet.contains(key)) {
      words.each { word ->
        word = word.replaceAll(/\[.*]/, "").toLowerCase()
        if (shouldAdd(word, present)) {
          present.add(word)
          println "word $word"
          outstream << "$word : 1${System.getProperty('line.separator')}"
          ++wordcount
        }
      }
    }
    wordcount
  }
  
  def shouldAdd(word, present){
    !present.contains(word) && !(word ==~ ".*[\\s-'].*") && word.size() > 0
  }
  
  def getInputStreams() {
    [mwData: new File("${dataPath}mwData.csv"), sd: new File("${dataPath}school.franklin")]
  }
  
}
