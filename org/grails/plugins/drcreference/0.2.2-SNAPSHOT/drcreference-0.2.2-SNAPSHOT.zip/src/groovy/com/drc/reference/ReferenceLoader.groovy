package com.drc.reference

import static groovy.io.FileType.FILES

import org.apache.log4j.Logger
import com.drc.ref.Ref


public class ReferenceLoader {

  static Logger log = Logger.getLogger(ReferenceLoader.class);

  private String referenceType;
  private String referenceFileDir;
  private String suffix = ".json";
  def RefParser refParser

  public ReferenceLoader(){
    this('dictionary', 'dictionary/', '.json')
  }
  
  public ReferenceLoader(referenceType, referenceFileDir, suffix = '.json') {
    this.referenceType = referenceType
    this.referenceFileDir = referenceFileDir
    this.suffix = suffix
    
    refParser = new RefParser(referenceType)
  }

  public void loadReference() {
    def refCount = Ref.countByReference(referenceType)
    log.info("Row count for $referenceType: ${refCount}")
    if (refCount == 0) {
      long starttime = System.currentTimeMillis();
      log.info("Loading " + referenceType + " reference...");
      prepReference();
      log.info(referenceType + " reference load complete in: "
          + (System.currentTimeMillis() - starttime));
    }else{
      log.info(referenceType + "reference db is already loaded.");
    }
  }

  public void prepReference() {
    def path = Thread.currentThread().getContextClassLoader().getResource(referenceFileDir).getFile()
    
    new File(path).eachFile(FILES) {
      if(it.name.endsWith('.json')) {
        loadFile(it);
      }
    }
  }

  protected void loadFile(File file) throws Exception {
    try {
      log.info("Loading reference file: " + file.getAbsolutePath());
      refParser.parse(file)
    } catch (Exception e) {
      e.printStackTrace(System.out)
      throw new RuntimeException("Problem parsing json file: "
          + file.getAbsolutePath(), e);
    }
  }
    
  public void setReferenceType(String referenceType) {
    this.referenceType = referenceType;
  }

  public void setReferenceFileDir(String referenceFileDir) {
    this.referenceFileDir = referenceFileDir;
  }

  public void setFileSearchSuffix(String suffix) {
    this.suffix = suffix;
  }
  
  public void setRefParser(RefParser refParser) {
    this.refParser = refParser;
  }
}