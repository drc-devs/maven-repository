package com.drc.reference

import org.codehaus.jackson.JsonParser
import org.codehaus.jackson.JsonFactory
import org.codehaus.jackson.JsonParser
import org.codehaus.jackson.JsonToken

import com.drc.ref.Ref

class RefParser {
  
  private JsonFactory jfactory = new JsonFactory();
  def referenceType
  def spellCheckParser
  def grailsApplication
  def outstream
  
  RefParser(){
    this.spellCheckParser = new SpellCheckParser()
    
    def path = grailsApplication?.config?.drcreference?.prepReference ?
               grailsApplication.config.drcreference.prepReference :
               'target/dictionary.txt'
    this.outstream = new FileOutputStream(path)
  }
  
  RefParser(referenceType) {
    this()
    this.referenceType = referenceType
  }
  
  RefParser(referenceType, outstream) {
    this(referenceType)
    if (outstream)
      this.outstream = outstream
  }
  
  def parse(file) {  
      JsonParser jParser = jfactory.createJsonParser(file);
  
      int hierarchy = 0;
      StringBuilder sb = new StringBuilder("");
      String word = null;
  
      while (jParser.nextToken() != null) {
  
        if (jParser.getCurrentToken() == JsonToken.START_OBJECT)
          ++hierarchy;
        if (jParser.getCurrentToken() == JsonToken.END_OBJECT)
          --hierarchy;
  
        if (tokenReferencesReferenceWordLabel(hierarchy, jParser)) {
          if (word != null) {
            writeReference(word, sb.toString());
            sb = new StringBuilder("");
          }
          word = jParser.getCurrentName();
        } else {
  
          if (jParser.getCurrentToken().isNumeric()) {
            sb.append(jParser.getText()).append(',');
          }
          else if (jParser.getCurrentToken() == JsonToken.FIELD_NAME) {
            sb.append('"').append(jParser.getText()).append("\":");
          }
          else if (jParser.getCurrentToken().isScalarValue()) {
            sb.append('"').append(jParser.getText().replaceAll("\"", "\\\""))
                .append("\",");
          }
          else {
            if (hierarchy > 0) {
              if (theLastCharacterIsAComma(sb) && theCurrentTokenIsAClosingBracket(jParser)) {
                sb.deleteCharAt(sb.length() - 1);
              }
  
              // definitions should start with JsonToken.START_ARRAY character
              if (!theInitialStartObject(sb, jParser)) {
                if (improperlyDelimited(sb, jParser)) {
                  sb.append(',');
                }
                sb.append(jParser.getCurrentToken().asString());
              }
  
              if (theCurrentTokenIsAClosingBracket(jParser) && (hierarchy != 1)) {
                sb.append(",");
              }
  
            }
          }
        }
      }
  
      // write the final definition
      writeReference(word, sb.toString());
  }
    
  private boolean tokenReferencesReferenceWordLabel(int hierarchy, JsonParser jParser){
    return hierarchy == 1 && jParser.getCurrentToken() == JsonToken.FIELD_NAME;
  }
  
  private boolean theLastCharacterIsAComma(StringBuilder sb){
    return sb.length() > 0 && sb.charAt(sb.length() - 1) == ',';
  }
  
  private boolean theCurrentTokenIsAClosingBracket(JsonParser jParser){
    return jParser.getCurrentToken() == JsonToken.END_OBJECT || jParser.getCurrentToken() == JsonToken.END_ARRAY;
  }
  
  private boolean theInitialStartObject(StringBuilder sb, JsonParser jParser){
    return sb.length() == 0 && jParser.getCurrentToken() == JsonToken.START_OBJECT;
  }
  
  private boolean improperlyDelimited(StringBuilder sb, JsonParser jParser){
    return sb.length() > 0 && jParser.getCurrentToken() == JsonToken.START_OBJECT && ",[:".indexOf(sb.charAt(sb.length() - 1).toString()) == -1;
  }

  protected void writeReference(String word, String refValue) {
    Ref reference = new Ref(reference: referenceType, word: word, referenceValue: refValue)
    reference.save()
  }
  
  public void setReferenceType(referenceType){
    this.referenceType = referenceType
  }
}
