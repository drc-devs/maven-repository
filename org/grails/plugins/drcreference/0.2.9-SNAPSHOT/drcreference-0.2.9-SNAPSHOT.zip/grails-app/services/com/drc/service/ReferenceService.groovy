package com.drc.service

import grails.converters.JSON
import groovy.json.JsonBuilder
import groovy.json.JsonSlurper

import com.drc.ref.Ref

class ReferenceService {
  //grails.plugin.searchable.SearchableService
  def searchableService
  def spellChecker
  def spellCheckDictionary

  def getReference(params) {
    def slurp = new JsonSlurper()
    JsonBuilder builder = new JsonBuilder()
    List refs = query(params)

    def root = builder {
      defs(
          refs.collect { Ref r -> [word: r.word, value: slurp.parseText(r.referenceValue.replace("\\", "\\\\"))] }
      )
    }

    builder.toString()
  }

  def query(params) {
    def searchResult = []
    
    try {
      searchResult = Ref.findAllByReferenceAndWord(params.reference, params.word)
    } catch (ex) {
      log.error('Trouble searching the reference db. Make sure a value for drcreference.ds is specified in Config.groovy', ex)
    }
    
    if (searchResult == [] && params.fuzzyLimit) {
      def search = "reference:$params.reference ${params.word.replaceAll(" ", "~ ")}~"
      searchResult = searchableService.search(search.toString(), [defaultProperty: "word", max: params.fuzzyLimit]).results
    }

    searchResult
  }
  
  def spellCheck(word, maxSuggestions) {
    Vector words = spellChecker.spellCheck(word)
    def suggestions
    if (!words.isEmpty())
      suggestions = new ArrayList(spellChecker.spellCheck(word))
    else
      suggestions = new ArrayList()
    def phoneticMatches = spellCheckDictionary.phoneticMatches(word)
    if (!phoneticMatches.isEmpty() && phoneticMatches[0] != null)
      suggestions = (suggestions << phoneticMatches).flatten()
      suggestions.unique()

    (suggestions.size() > maxSuggestions) ? suggestions[0..maxSuggestions - 1] : suggestions
  }
  
  def wordList() {
    def returnValue = [:]
    def words = spellCheckDictionary.words.sort()
    
    words.collect {
      returnValue.put("$it", true)
    }
    
    returnValue = returnValue as JSON
    returnValue
  }
}
