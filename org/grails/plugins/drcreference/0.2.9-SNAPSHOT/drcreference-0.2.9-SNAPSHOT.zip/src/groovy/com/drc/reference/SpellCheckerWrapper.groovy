package com.drc.reference

import pt.tumba.spell.SpellChecker

class SpellCheckerWrapper {
  private SpellChecker spellChecker
  
  SpellCheckerWrapper(){}
  
  SpellCheckerWrapper(def dictionary){
    spellChecker = new SpellChecker()
    spellChecker.initialize(dictionary);
  }
  
  def spellCheck(word) {
    spellChecker.findMostSimilarList(word, true)
  }
}
