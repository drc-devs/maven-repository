package com.drc.reference

class FileHelper {
  static def findFile(location) {
    //in classpath?
    def file = Thread.currentThread().getContextClassLoader().getResource(location)?.path
    //if not in classpath check if its an fs path
    if (!file) {
      def dicFile = new File(location)
      if (dicFile.exists())
        file = dicFile.path
    }
    
    file
  }
}
