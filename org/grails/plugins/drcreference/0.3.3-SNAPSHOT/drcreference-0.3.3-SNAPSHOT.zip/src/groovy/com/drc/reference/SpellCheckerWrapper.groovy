package com.drc.reference

class SpellCheckerWrapper {
  private DrcSpellChecker spellChecker
  
  SpellCheckerWrapper(){}
  
  SpellCheckerWrapper(def dictionary){
    spellChecker = new DrcSpellChecker()
    spellChecker.initialize(dictionary);
  }
  
  SpellCheckerWrapper(def dictionary, def commonMisspell){
    spellChecker = new DrcSpellChecker()
    spellChecker.initialize(dictionary, commonMisspell);
  }
  
  def spellCheck(word) {
    spellChecker.findMostSimilarList(word, true)
  }
}
