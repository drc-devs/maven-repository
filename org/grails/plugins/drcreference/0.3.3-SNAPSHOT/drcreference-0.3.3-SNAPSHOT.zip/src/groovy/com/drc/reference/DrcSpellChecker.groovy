package com.drc.reference

import pt.tumba.spell.SpellChecker
import pt.tumba.spell.StringUtils

/**
 * Created by Lee Davis on 03/04/2015.
 */
class DrcSpellChecker extends SpellChecker {

  /**
   * I don't know the history of this change for DRC Spellcheck, but here we are.
   * This was originally changed directly in the JaSpell Library with no comments.
   * I have broken out on its own here to try and isolate JaSpell from modification.
   */
  @Override
  public synchronized List findMostSimilarList(String key, boolean heuristics) {
    List aux = new ArrayList();
    int size = key.length();
    if (size == 0) return aux;
    if(commonErrors!=null) {
      String[] auxerr = commonErrors.find(key);
      if(auxerr!=null && auxerr.length>0) {
        for(int i=0; i<auxerr.length; i++) aux.add(auxerr[i]);
        return aux;
      }
    }
    int maxAux = 1;
    int i;
    int j;
    String auxs;
    String auxs2;

    // maximum of 2 letters difference
    for (maxAux = 1;
         maxAux <= 2 && aux.size() == 0 && size >= maxAux * 2;
         maxAux++) {
      dictionary.setMatchAlmostDiff(maxAux);
      aux = dictionary.matchAlmost(key);
    }

    // 1 letter removed or added and 1 letter removed or added and 1 different
    if (size > 2 && (!heuristics || aux.size() == 0)) {
      for (maxAux = 0; maxAux <= 1 && aux.size() == 0; maxAux++) {
        dictionary.setMatchAlmostDiff(maxAux);
        for (i = size - 1; i >= 0; i--) {
          aux.addAll(dictionary.matchAlmost(key.substring(0, i) + key.substring(i + 1, size)));
          for (j = 'a'; j < 'z'; j++) {
            aux.addAll(dictionary.matchAlmost(
                key.substring(0, i)
                    + ((char) j)
                    + key.substring(i, size)));
          }
          for (j = 0; j < StringUtils.getSpecialChars().length; j++) {
            aux.addAll(dictionary.matchAlmost(
                key.substring(0, i)
                    + StringUtils.getSpecialChars()[j]
                    + key.substring(i, size)));
          }
        }
      }
    }
    if (!heuristics || aux.size() == 0) {
      for (i = 0; i < size - 1; i++) {
        auxs = key.charAt(i + 1) +
          key.charAt(i) +
          key.substring(i + 2, size);
      }
    }
    if (!heuristics || aux.size() == 0) {
      for (i = 1; i < size - 1; i++) {
        if (key.charAt(i) == key.charAt(i - 1)) {
          auxs = key.substring(0, i) + key.substring(i + 1, size);
        }
      }
    }
    return aux;
  }
}
