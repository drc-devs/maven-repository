package com.drc.reference

class DictionaryReader {
  private words = []
  public DictionaryReader(dictionary){
    def fullPath = Thread.currentThread().getContextClassLoader().getResource(dictionary).getFile()
    def dictFile = new File(fullPath)
    
    dictFile.eachLine {
      words << it.split(' : ')[0]
    }
  }
  
  public getWords(){
    //make defensive copy?
    words
  }
}