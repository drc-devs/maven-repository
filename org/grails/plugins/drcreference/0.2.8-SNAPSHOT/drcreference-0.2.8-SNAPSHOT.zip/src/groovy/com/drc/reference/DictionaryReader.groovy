package com.drc.reference

import pt.tumba.spell.Phonetic

class DictionaryReader {
  private words = []
  private phoneticsSoundex = [:]
  private phoneticsMetaphone = [:]
  private phoneticsDoubleMetaphone = [:]
  public DictionaryReader(dictionary){
    def dictFile = new File(dictionary)
    
    dictFile.eachLine {
      def word = it.split(' : ')[0]
      words << word
      setupPhonetics(word)
    }
  }
  
  private setupPhonetics(word){
    def phoneticGenerator = Phonetic.getInstance()
    ["Soundex", "Metaphone", "DoubleMetaphone"].each { algorithm ->
      def phonetic = phoneticGenerator."get$algorithm"(word)
      if (!this."phonetics$algorithm"[phonetic]) {
        this."phonetics$algorithm"[phonetic] = []
      }
      this."phonetics$algorithm"[phonetic][this."phonetics$algorithm"[phonetic].size()] = word
    }
  }
  
  public getWords(){
    //make defensive copy?
    words
  }
  
  public phoneticMatches(word){
    def phoneticGenerator = Phonetic.getInstance()
    def results = []
    def soundex = phoneticsSoundex[phoneticGenerator.getSoundex(word)]
    results.add soundex
    def metaPhone = phoneticsMetaphone[phoneticGenerator.getMetaphone(word)]
    results.add(metaPhone)
    def doubleMetaPhone = phoneticsDoubleMetaphone[phoneticGenerator.getDoubleMetaphone
        (word)]
    results.add(doubleMetaPhone).unique()
  }
}