package com.drc.reference

import org.apache.log4j.Logger;

class FileHelper {
  static Logger log = Logger.getLogger(ReferenceLoader.class);
  
  static def findFile(location) {
    def file
    try {
      //in classpath?
      file = Thread.currentThread().getContextClassLoader().getResource(location)?.path
      //if not in classpath check if its an fs path
      if (!file) {
        def dicFile = new File(location)
        if (dicFile.exists())
          file = dicFile.path
      }
    } catch (Exception e) {
      println "problem loading file"
      log.error("problem loading file", e)
    }
    
    file
  }
}
