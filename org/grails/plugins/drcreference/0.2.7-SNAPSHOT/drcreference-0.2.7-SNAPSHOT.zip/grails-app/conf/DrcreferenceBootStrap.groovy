import com.drc.reference.ReferenceLoader

class DrcreferenceBootStrap {

  def searchableService
  def grailsApplication
  
  def init = { servletContext ->
    if (grailsApplication.config.drcreference.prepReference)
	  prepReference()
  }

  def prepReference() {
    println "prepping references"
    searchableService.stopMirroring()
    new ReferenceLoader("thesaurus", "thesaurus/").loadReference()
    new ReferenceLoader().loadReference()
    searchableService.startMirroring()
    searchableService.index()
  }

  def destroy = {
  }
}
