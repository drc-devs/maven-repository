package com.drc

import grails.converters.JSON
import org.codehaus.groovy.grails.web.json.JSONObject

class ReferenceController {

  def referenceService
  
  def spellCheck() {
    def returnValue = [misspells: []]
    def spellBody = request.JSON
    def text = spellBody.text.replaceAll("[^'\\-0-9A-Za-z\\s]", "")
    def numSuggestions = params.maxSuggest.toInteger()
    
    text.tokenize().each { 
      def results = referenceService.spellCheck(it, numSuggestions ?: 5)
      
      returnValue.misspells.push([word: it, suggestions: results])
    }

    response.status = 200
    render(contentType: "text/json") {returnValue} as JSON
  }
  
  def lookupReference() {

    log.debug("$params.reference lookup for word: $params.word")

    if (!params.reference || !params.word) {
      custRespond(200, new JSONObject(warning:'please provide a reference and lookup word'))
    } else {
      def refs = JSON.parse(referenceService.getReference(params))

      if (refs.defs.size() == 0)
        custRespond(200,
          new JSONObject(
            warning:"no references found in $params.reference for $params.word",
            reference:params.reference,
            word:params.word))
      else
        custRespond(200, refs)
    }
  }
  
  def referenceKeys() {
    def refs = referenceService.wordList()
    log.error(refs)
    if (!refs || "$refs".equals("{}")) {
      custRespond(200,
        new JSONObject(
          warning:"no spell check references found",
          reference:params.reference,
          word:params.word))
    } else {
      def huh = JSON.parse("$refs")
      log.error(huh)
      custRespond(200, JSON.parse("$refs"))
    }
  }

  private def custRespond(status, content) {
    response.status = status
    render(contentType: "text/json") {content}
  }
}
