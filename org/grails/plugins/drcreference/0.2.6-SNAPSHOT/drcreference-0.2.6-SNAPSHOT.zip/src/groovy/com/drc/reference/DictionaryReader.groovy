package com.drc.reference

import groovy.json.JsonBuilder

class DictionaryReader {
  private words = []
  public DictionaryReader(dictionary){
    def dictFile = new File(dictionary)
    
    dictFile.eachLine {
      words << it.split(' : ')[0]
    }
  }
  
  public getWords(){
    //make defensive copy?
    words
  }
}