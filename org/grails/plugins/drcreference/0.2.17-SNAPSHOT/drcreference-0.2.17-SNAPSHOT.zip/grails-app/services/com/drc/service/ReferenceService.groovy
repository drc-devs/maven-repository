package com.drc.service

import com.drc.ref.Ref
import grails.converters.JSON
import groovy.json.JsonSlurper

class ReferenceService {
  def searchableService
  def spellChecker
  def spellCheckDictionary

  def getReference(params) {
    def slurp = new JsonSlurper()
    List refs = query(params)

    [defs: refs.collect { Ref r ->
      [word: r.word, value: slurp.parseText(r.referenceValue.replace("\\", "\\\\"))]
    }]
  }

  def query(params) {
    def searchResult = []

    try {
      searchResult = Ref.findAllByReferenceAndWord(params.reference, params.word)
    } catch (ex) {
      log.error('Trouble searching the reference db. Make sure a value for drcreference.ds is specified in Config.groovy', ex)
    }

    if (searchResult == [] && params.fuzzyLimit) {
      def search = "reference:$params.reference ${params.word.replaceAll(" ", "~ ")}~"
      searchResult = searchableService.search(search.toString(), [defaultProperty: "word", max: params.fuzzyLimit]).results
    }

    searchResult
  }

  def spellCheck(word, maxSuggestions) {
    Vector words = spellChecker.spellCheck(word)
    def suggestions
    if (!words.isEmpty())
      suggestions = new ArrayList(spellChecker.spellCheck(word))
    else
      suggestions = new ArrayList()
    def phoneticMatches = spellCheckDictionary.phoneticMatches(word)
    if (!phoneticMatches.isEmpty()) {
      suggestions = (suggestions << phoneticMatches).flatten() - null
    }
    suggestions.unique()

    // Think about how abstracting this to allow for more robust ranking logic. i.e. rank filter chaining
    suggestions = rankSuggestions(word, suggestions)

    (suggestions.size() > maxSuggestions) ? suggestions[0..maxSuggestions - 1] : suggestions
  }

  def rankSuggestions(word, suggestions){
    def rancor = []

    suggestions.each {
      rancor.add([suggestion: it, copy: new StringBuilder(it), rank: 0])
    }

    def chars = word.toCharArray()
    chars.eachWithIndex { character, index ->
      character = character.toString()
      rancor.each {
        def matchIndex = it.copy.indexOf(character)

        if (matchIndex >= 0) {
          if (index == 0 && matchIndex == 0){
            it.rank += 2
          } else {
            it.rank++
          }
          it.copy.delete(matchIndex, matchIndex+1)
        }

        if (index == chars.length - 1) {
          it.rank -= it.copy.size()
        }
      }
    }

    rancor.sort { a, b ->
      b.rank <=> a.rank
    }

    rancor.suggestion
  }

  def wordList() {
    def returnValue = [:]
    def words = spellCheckDictionary.words.sort()

    words.collect {
      returnValue.put("$it", true)
    }

    returnValue = returnValue as JSON
    returnValue
  }
}
