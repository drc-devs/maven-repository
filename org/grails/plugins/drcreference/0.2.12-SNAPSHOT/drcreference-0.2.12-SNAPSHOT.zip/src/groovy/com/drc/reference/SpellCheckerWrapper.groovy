package com.drc.reference

import pt.tumba.spell.SpellChecker

class SpellCheckerWrapper {
  private SpellChecker spellChecker
  
  SpellCheckerWrapper(){}
  
  SpellCheckerWrapper(def dictionary){
    spellChecker = new SpellChecker()
    spellChecker.initialize(dictionary);
  }
  
  SpellCheckerWrapper(def dictionary, def commonMisspell){
    spellChecker = new SpellChecker()
    spellChecker.initialize(dictionary, commonMisspell);
  }
  
  def spellCheck(word) {
    spellChecker.findMostSimilarList(word, true)
  }
}
