package com.drc.reference

import org.apache.commons.io.FileUtils

import java.nio.charset.Charset

class SpellCheckParser {
  final static String DATA_PATH = 'spellcheck'
  final static String OUTPUT_PATH = "target/tomcat-db/spelling"
  final static String DICTIONARY_WORDS_INPUT = 'mwData.csv'
  final static String DICTIONARY_WORDS_OUTPUT = 'dictionary.txt'


  def grailsApplication
  def dataPath = DATA_PATH
  def outputPath = OUTPUT_PATH
  TreeSet present = new TreeSet()

  SpellCheckParser(){

    def referenceConfig = grailsApplication?.config?.drcreference

    if (referenceConfig) {
      dataPath = referenceConfig.spellingDataDir ?: DATA_PATH
      outputPath = referenceConfig.dictionaryPath ?: OUTPUT_PATH
    }

    def outfile = new File(outputPath)
    FileUtils.deleteDirectory(outfile)
    outfile.mkdirs()
    dataPath = Thread.currentThread().getContextClassLoader().getResource(dataPath).getFile()
  }

  def createSpellcheckDictionary() {
    def inReader = null
    def outWriter = null
    String line = null

    try {
      inReader = getInReader()
      outWriter = getOutWriter()
      while ((line = inReader.readLine()) != null) {
        getWordFromLine(line).each { writeWord(it, outWriter) }
      }
      outWriter?.flush()
    }
    catch (Exception e) {
      e.printStackTrace()
      throw e
    }
    finally {
      outWriter?.close()
      inReader?.close()
    }
    present.size()
  }

  private void writeWord(String word, Writer outWriter) {
    if (shouldAdd(word, present)) {
      present.add(word)
      outWriter.write("$word : 1")
      outWriter.newLine()
    }
  }

  def shouldAdd(word, present){
    word.size() > 0 && !present.contains(word) && !(word ==~ ".*[\\s-:;.,&()].*")
  }

  def getWordFromLine(String line) {
    line.replaceAll(/\[.*]/, "").split("[\\s+|,]")
  }

  def getInReader() {
    //Note: Encoding not consistent, not enforcing specific decoding
    def isr = new InputStreamReader(new FileInputStream(dataPath + File.separator + DICTIONARY_WORDS_INPUT))
    println("Processing Dictionary: ${dataPath + File.separator + DICTIONARY_WORDS_INPUT}.  Using encoding: ${isr.getEncoding()}")
    new BufferedReader(isr)
  }

  def getOutWriter() {
    def utf8Encoder = Charset.forName("UTF-8").newEncoder();
    new BufferedWriter(new OutputStreamWriter(new FileOutputStream(OUTPUT_PATH + File.separator + DICTIONARY_WORDS_OUTPUT), utf8Encoder))
  }
}
